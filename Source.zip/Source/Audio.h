//
//

#ifndef Audio_h
#define Audio_h

#include <stdio.h>

#include "irrKlang.h"

#include "Timer.h"
#include "Utilities.h"

using namespace irrklang;


class Audio
{
  ISoundEngine* engine;
  
  ISoundSource* groupScream;
  vector<ISoundSource*> screams;
  
  Timer screamTimer;

public:
  Audio();
  ~Audio();
  
  void playScream();
  
  void playGroupScream();
  void setVolume(float speed);
};


#endif /* Audio_h */
