//
//

#ifndef Shader_h
#define Shader_h

#include <stdio.h>
#include <iostream>
#include <fstream>
#include <iterator>
#include <algorithm>

#include "Utilities.h"

#include "Camera.h"

using namespace std;

GLuint CompileShader(GLenum shaderType, const string &source);
GLuint LinkProgram(GLuint vertexShader, GLuint fragmentShader);
string LoadSource(const string &filename);

class Shader
{
  // OpenGL names for vertex and fragment shaders, shader program
  GLuint vertex;
  GLuint fragment;

  GLint viewLoc;
  GLint projLoc;
  GLint modelLoc;

  GLint scaleLoc;
  
public:

  Shader();
  ~Shader();

  GLuint program;

  void updateView(mat4);
  void updateProj(mat4);
  void updateModel(mat4);
  void updateScale(vec3);
};


#endif /* Shader_h */

