//
//

#include "Audio.h"


Audio::Audio()
{
  engine = createIrrKlangDevice();
  
  if (!engine)
    cout << "Audio Initialization Failure" << endl; // error starting up the engine
  
  screams.push_back(engine->addSoundSourceFromFile("assets/Scream1.wav"));
  screams.push_back(engine->addSoundSourceFromFile("assets/Scream2.wav"));
  screams[1]->setDefaultVolume(0.65);
//  screams.push_back(engine->addSoundSourceFromFile("assets/Scream3.wav"));
//  screams.push_back(engine->addSoundSourceFromFile("assets/Scream4.wav"));
  
  groupScream = engine->addSoundSourceFromFile("assets/Group.wav");
}

Audio::~Audio()
{
  engine->drop();
  
  for (ISoundSource* scream : screams)
    delete scream;
  
  delete groupScream;
}

void Audio::playGroupScream()
{
  if (!engine->isCurrentlyPlaying(groupScream))
    engine->play2D(groupScream, false);
}

void Audio::setVolume(float speed)
{
  float volume = std::min(1.0, std::max(0.0, speed - 1.0));
  engine->setSoundVolume(volume);
}

void Audio::playScream()
{
  int index = rand() % screams.size();
  
  if (!engine->isCurrentlyPlaying(screams[index]) && (screamTimer.elapsedSeconds() > 0.7 || !screamTimer.m_bRunning)) {
    engine->play2D(screams[index], false);
    screamTimer.stop();
    screamTimer.start();
  }
}


