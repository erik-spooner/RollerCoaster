CPSC 687 Animation Assignment 1 RollerCoaster Simulation.
Erik Spooner - 10111209

The track is calculated via a 5th order NURBS curve. The speed of the carts is determined by the distance along the track. At the start and end of the track the cart's speed is calculated by a simple function, everywhere else the speed of the cart is calculated via conservation of energy (balancing kinetic energy and gravitation potential energy) as discussed in class and tutorial. The Orientation of the cart and track was calculated via a Frenet frame, where the normal vector of the frame was in the opposite direction of the force acting on the cart so that the passengers would feel no forces perpendicular to the normal. 


Controls

Right mouse button to rotation a spherical camera
LShift + Right mouse button to move the spherical camera

Q to position the camera at strategic points and follow the carts as they travel the track.

R to position the camera on the front cart and look ahead.

Decrease or increase the volume to control how much Philmo's scream disturbs your neighbours.