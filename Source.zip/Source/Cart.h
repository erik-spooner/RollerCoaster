//
//

#ifndef Cart_h
#define Cart_h

#include <stdio.h>

#include "SceneObject.h"

typedef enum : int {
  ControlledAcceleration = 0,
  ControlledDecceleration = 1,
  EnergyConservation = 2,
} SpeedControl;

class Cart : public SceneObject
{
  vector<SceneObject*> wheels;
  
public:
  float speed = 1.0;
  float position = 0.0;
  
  float deccelerationSpeed = 1.0;
  float initialSpeed = 1.0;
  
  SpeedControl speedType = ControlledAcceleration;
  
  float mass = 1.0;

  // updates the rotation of the wheels from the arklength position of the cart
  void updateWheels();
  
  Cart();
  ~Cart();
  
};

#endif /* Cart_h */
