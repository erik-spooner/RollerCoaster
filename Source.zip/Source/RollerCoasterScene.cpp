//
//

#include "RollerCoasterScene.h"


RollerCoasterScene::RollerCoasterScene()
{
  track = new NURBS();
  loadTrackFromFile("Track.txt");
  children.push_back(track);
  track->isRendered = false;
  
  // Create the carts
  float pos = 0.6;
  for (int i = 0; i < numCarts; ++i, pos -= 0.2) {
    Cart* cart = new Cart();
    SceneObject::createCube(cart, vec3(0, 0.55, 0));
    
    cart->position = pos;
    
    carts.push_back(cart);
    children.push_back(cart);
  }
  
  for (int i = 0; i < numCarts - 1; ++i) {
    SceneObject* link = new SceneObject();
    SceneObject::createCube(link, vec3(0, 0.75, 0));
    
    link->setScale(vec3(0.2, 0.025, 0.025));
    
    links.push_back(link);
    children.push_back(link);
  }
  
  groundPlane = new SceneObject();
  children.push_back(groundPlane);
  
  skyBox = new SceneObject();
  children.push_back(skyBox);
  
  audioPlayer = new Audio();
  
  setupScene();
  
  camera = new Camera();
  cameraType = POSITIONAL;
  
  primativeType = GL_TRIANGLE_STRIP;
  calculateTrack();
}



RollerCoasterScene::~RollerCoasterScene()
{
  delete audioPlayer;
}



void RollerCoasterScene::calculateTrack()
{
  float length = track->totalLength;
  
  for (float s = 0.0; s < length; s += 0.025) {
    
    vec3 position = track->calculatePosition(s);
    mat3x3 frame = calculateFrame(s);
    
    vec3 binormal = frame[2];
    
    vec3 a = position + binormal * trackWidth;
    vec3 b = position - binormal * trackWidth;

    pushLine(b, a, vec3(1.0, 0.0, 1.0), vec3(1.0, 1.0, 0.0));
  }
  
  vec3 position = track->calculatePosition(0.0);
  mat3x3 frame = calculateFrame(0.0);
  
  vec3 binormal = frame[2];
  
  vec3 a = position + binormal * trackWidth;
  vec3 b = position - binormal * trackWidth;

  pushLine(b, a, vec3(1.0, 0.0, 1.0), vec3(1.0, 1.0, 0.0));
  
  updateVertices();
}


void RollerCoasterScene::update(float t)
{
  float speed = 0.0;
  for (int i = 0; i < numCarts; ++i) {
    float pos = carts[i]->position;
    speed += calculateSpeed(pos);
  }
  
  speed /= (float) numCarts;
  
  // Update the carts
  for (int i = 0; i < numCarts; ++i) {
    float newPos = carts[i]->position + speed * t;
    
    carts[i]->position = newPos;
    carts[i]->speed = speed;
    
    // update the visual position and orientation of the cart
    vec3 position = track->calculatePosition(newPos);
    mat3x3 frame = calculateFrame(newPos);
    carts[i]->setLocalPosition(position);
    carts[i]->setLocalRotation(frame);
    carts[i]->updateWheels();
  }
  
  // Update the links
  for (int i = 0; i < numCarts - 1; ++i) {
    float s = (carts[i]->position + carts[i + 1]->position) / 2.0;
    
    vec3 position = track->calculatePosition(s);
    mat3x3 frame = calculateFrame(s);
    links[i]->setLocalPosition(position);
    links[i]->setLocalRotation(frame);
  }
  
  // update the camera
  switch (cameraType) {
    case FREE_FORM:
      // Don't have to do anything
      break;
      
    case RIDE_ALONG:
      rideAlongCamera(carts[0]->position);
      break;
      
    case POSITIONAL:
      positionalCamera(carts[0]->position);
      break;

    default:
      break;
  }
  
  mat3x3 frame = calculateFrame(carts[0]->position);
  
  // calculate the sound
  mat3x3 nextFrame = calculateFrame(carts[0]->position + calculateSpeed(carts[0]->position) * 20.0 * t);
  

  if (dot(frame[0], vec3(0.0, -1.0, 0.0)) > 0.7 && calculateSpeed(carts[0]->position) > 2.0)
    audioPlayer->playGroupScream();

  if (dot(nextFrame[1], frame[1]) < 0.5)
    audioPlayer->playScream();
  else if (0.1 > abs(dot(frame[1], vec3(0.0, 1.0, 0.0))))
    audioPlayer->playScream();  
  
  audioPlayer->setVolume(speed / 2.0);
}


void RollerCoasterScene::rideAlongCamera(float s)
{
  vec3 position = track->calculatePosition(s);
  mat3x3 frame = calculateFrame(s);
  
  vec3 eye = frame[1];
  eye *= 0.2; eye += position;
  vec3 lookAt = track->calculatePosition(s + 0.7);
  
  // update the camera depending on the mode
  camera->lookAt(eye, lookAt, frame[1]);
}

void RollerCoasterScene::positionalCamera(float s)
{
  vec3 position = track->calculatePosition(s);
  
  int index = -1;
  float shortestLength = 99999999.9;
  
  for (int i = 0; i < cameraPositions.size(); ++i) {
    float length = glm::length(position - cameraPositions[i]);
    if (length < shortestLength) {
      shortestLength = length;
      index = i;
    }
  }
  
  if (index == -1)
    return;
  
  vec3 eye = cameraPositions[index];
  vec3 lookAt = position;
  
  camera->lookAt(eye, lookAt);
}


float RollerCoasterScene::calculateSpeed(float s)
{
  float highestPoint = track->highestPoint;
  
  float decelerationSpeed = 1.0;
  
  float h = track->calculatePosition(track->totalLength * 0.9).y;
  
  decelerationSpeed = sqrtf(1.0 + gravity.y * (track->maxHieght - h));
  
  s = track->wrapS(s);
  
  float speed;
  
  // Starting part of the track
  if (s < 1.0 || s < highestPoint) {
    speed = std::max(0.01, std::min(-0.11 + s / (float) numCarts, 1.0));
  }
  // ending part of the track
  else if (s / track->totalLength > 0.9) {
    speed = decelerationSpeed * std::max((1.0 - (s / track->totalLength)) * 10.0, 0.0) + 0.01;
  }
  // energy conservation
  else {
    h = track->calculatePosition(s).y;
    speed = sqrtf(1.0 + gravity.y * (track->maxHieght - h));
  }
  
  return speed;
}

mat3x3 RollerCoasterScene::calculateFrame(float s)
{
  // Get the speed of the cart at s
  float dt = 1.0 / 60.0;
  
  float v = calculateSpeed(s);
  
  // get the tangent and normal
  vec3 tangent = track->calculateTangent(s, std::max((double)v * dt, 0.01));
  vec3 normal = track->calculateNormal(s, std::max((double)v * dt, 0.01));
  
  // Ensure the tangent is normalized
  tangent = normalize(tangent);

  // Find normal vector
  normal = gravity + normal * v * v;
  
  // normalize the normal
  normal = normalize(normal);
  
  // Make the normal perpendicular the tangent;
  normal = normal - tangent * dot(normal, tangent);
  normal = normalize(normal);
  
  // Get the binormal vector
  vec3 binormal = normalize(cross(normal, tangent));
  
  // calculate the frame
  mat3x3 frame(tangent, normal, binormal);
  
  return frame;
}


void RollerCoasterScene::setupScene()
{
  /* b----d
   * | \  |
   * |  \ |
   * a----c
   */
  vec3 a = vec3(-1.0, 0.0, -1.0) * 25.0f;
  vec3 b = vec3(-1.0, 0.0, 1.0) * 25.0f;
  vec3 c = vec3(1.0, 0.0, -1.0) * 25.0f;
  vec3 d = vec3(1.0, 0.0, 1.0) * 25.0f;
  
  vec3 gray = vec3(0.4, 0.4, 0.4);
  
  vector<float> points;
  vector<float> colours;
  
  points.push_back(a.x);
  points.push_back(a.y);
  points.push_back(a.z);
  
  colours.push_back(gray.x);
  colours.push_back(gray.y);
  colours.push_back(gray.z);
  
  points.push_back(c.x);
  points.push_back(c.y);
  points.push_back(c.z);
  
  colours.push_back(gray.x);
  colours.push_back(gray.y);
  colours.push_back(gray.z);

  points.push_back(b.x);
  points.push_back(b.y);
  points.push_back(b.z);
  
  colours.push_back(gray.x);
  colours.push_back(gray.y);
  colours.push_back(gray.z);

  points.push_back(d.x);
  points.push_back(d.y);
  points.push_back(d.z);
  
  colours.push_back(gray.x);
  colours.push_back(gray.y);
  colours.push_back(gray.z);

  groundPlane->updateVertices(points, colours);
  groundPlane->primativeType = GL_TRIANGLE_STRIP;
}





void RollerCoasterScene::loadTrackFromFile(string fileName)
{
  json j;
  
  ifstream in(fileName);
  in >> j;
  in.close();
  
  vector<json> cameraPoses = j.at("cameraPositions").get<vector<json>>();
  
  for (int i = 0; i < cameraPoses.size(); ++i) {
    float x = cameraPoses[i].at("PositionX").get<float>();
    float y = cameraPoses[i].at("PositionY").get<float>();
    float z = cameraPoses[i].at("PositionZ").get<float>();
    
    cameraPositions.push_back(vec3(x,y,z) * track->scale);
  }
  
  track->fromJson(j);
}











