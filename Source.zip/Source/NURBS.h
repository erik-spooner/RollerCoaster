//
//

#ifndef NURBS_h
#define NURBS_h

#include <stdio.h>

#include "nlohmann/json.hpp"

#include "SceneObject.h"

using namespace nlohmann;

typedef pair<float, float> arkLengthForU;

struct WeightedPoint
{
  vec3 point;
  float weight;
  vec3 colour = vec3(0,0,1);
};

class NURBS : public SceneObject
{
protected:
  const float uInc = 0.00000099999;
  const float sInc = 0.01;
  
  // The order of the NURBS
  int order = 2;
  
  // The list of points, knots, and weights
  vector<WeightedPoint> points;
  vector<float> knots;
  
  vector<vec3> wPoints;
  vector<float> weights;
  
  // Stores the arcLength s and u parameter pairs
  vector<arkLengthForU> arkLength;
  
  void calculateArcLengths();
  
  // given a vector of type T calculate E_delta
  template <class T>
  T calculateEDelta(const vector<T> &E, const float &u);
  
  // Functions to calculate the vertices of the curve to draw.
  void calculateNURBS();
  
  // Function to change the knots so that they are in standard form.
  void standardizeKnots();
  
  // input a value u, find u_delta, can use deltaPrvious for a speed up
  int delta(float u, int deltaPrevious = 0);
  
  // input a integer index and a max size return an index that is within 0 <= i < maxSize
  int wrapIndex(int index, size_t maxSize);
  
  // returns the arklength distance for a given value u
  float getSFromU(float u);
  
  // calucates the point of the curve at a given u value
  vec3 calculatePositionU(float u);
  
  int countD = 0;
public:
  
  NURBS();
  
  const float scale = 10.0;

  // Stuff for making the Nurbs a loop
  // u values
  float trackStart = 0.0;
  float trackEnd = 1.0;
  float uLength = 1.0;
  
  float totalLength = 1.0; // arclength of the track
  
  float maxHieght = 0.0;
  float highestPoint = 0.0; // in arclength
  
  // input a value u, return a value of u that is within 0 <= u < 1
  float wrapU(float u);
  
  //
  float wrapS(float s);
  
  // Uses Arklength
  // calucates the point of the curve at a given s value
  vec3 calculatePosition(float s);
  
  // calculates the tangent to the curve at a given s value
  // (first derivative)
  vec3 calculateTangent(float s, float inc);
  
  // calculates the curvature of the curve at a given s value
  // (second derivative)
  vec3 calculateNormal(float s, float inc);

  
  // returns the value for u that has s distance from the start of the curve
  float getUFromArkLength(float s);
  
  void fromJson(json j);
};

#endif /* NURBS_h */
